let combos=[{
    title:'Customized Hair Growth Booster Hibiscus Combo',
    strickedPrice:1350,
    price:1198,
    id:1,
    image:'https://cdn.shopify.com/s/files/1/0037/7690/5283/products/customized-hair-growth-booster-hibiscus-combo_480x480.png?v=1634639909',
},
{
    title:'Greasy Scalp Hydration Kit',
    strickedPrice:1250,
    price:999,
    id:2,
    image:'https://cdn.shopify.com/s/files/1/0037/7690/5283/products/greasy-scalp-hydration-kit_480x480.jpg?v=1634638194',
},
{
    title:'Customized Hair Growth Booster Onion Combo',
    strickedPrice:1400,
    price:1198,
    id:3,
    image:'https://cdn.shopify.com/s/files/1/0037/7690/5283/products/customized-hair-growth-booster-onion-combo_480x480.png?v=1634639635',
},
{
    title:'Advanced Dandruff Care Duo',
    strickedPrice:2000,
    price:1798,
    id:4,
    image:'https://cdn.shopify.com/s/files/1/0037/7690/5283/products/advanced-dandruff-care-duo_480x480.png?v=1634639192',
},
{
    title:'Moisture Restore Duo 2',
    strickedPrice:1200,
    price:998,
    id:5,
    image:'https://cdn.shopify.com/s/files/1/0037/7690/5283/products/moisture_480x480.png?v=1634725003',
},
{
    title:'Hydrating Dandruff Care Duo',
    strickedPrice:999,
    price:798,
    id:6,
    image:'https://cdn.shopify.com/s/files/1/0037/7690/5283/products/hydrating-dandruff-care-duo_480x480.jpg?v=1634638467',
},
{
    title:'Customized Hair Growth Booster Banyan Combo',
    strickedPrice:1300,
    price:1198,
    id:7,
    image:'https://cdn.shopify.com/s/files/1/0037/7690/5283/products/customized-hair-growth-booster-banyan-combo_480x480.png?v=1634640099',
},
{
    title:'Moisture Restore Duo 1',
    strickedPrice:1100,
    price:998,
    id:8,
    image:'https://cdn.shopify.com/s/files/1/0037/7690/5283/products/moisture-restore-duo-1_480x480.png?v=1634638826',
},
{
    title:'Customized Hair Growth Booster Sage Combo',
    strickedPrice:1300,
    price:1198,
    id:9,
    image:'https://cdn.shopify.com/s/files/1/0037/7690/5283/products/customized-hair-growth-booster-sage-combo_480x480.png?v=1634639832',
},
{
    title:'Basic Hair Growth Essentials For Dry Scalp',
    strickedPrice:1000,
    price:798,
    id:10,
    image:'https://cdn.shopify.com/s/files/1/0037/7690/5283/products/basic-hair-growth-essentials-for-dry-scalp_480x480.png?v=1634639545',
}

];

localStorage.setItem("combo",JSON.stringify(combos));