function navbar1(){
    return `   <div id="nav">
    <div id="nav1">
 
 <div> 
    <p>
        Order Now & Get Assured Dispatch In 24hrs
        
    </p>
    <button id="navbutton">
    <a href="allproduct.html" style="text-decoration:none;color:black;">
    Order Now
    </a>
    </button> 
 </div>
 
    </div>
    <div id="nav2"> 
        <div>
        <a href="index.html" style="text-decoration:none;color:black;">
            <img src="https://cdn.shopify.com/s/files/1/0037/7690/5283/files/logo.svg?v=1585630376">
        </a>
            </div>
        <div>
       
            <p id="quiz1">
            <a href="quiz1.html" style="text-decoration:none;color:black;">
            Know Your Skin 
            </a>
            <i class="fas fa-angle-right"></i>
        </p>
 
        </div>
        <div>
            <p id="quiz2">
 
            <a href="comp.html" style="text-decoration:none;color:black;">
            Your Skin Analysis
            </a>
            <i class="fas fa-angle-right"></i> 
        </p>
        </div>
        <div class="cart" >
        
        <div style="display:flex; width:150px; justyfy-content:space-between;">
        <img  id='cart_sidebar' src="https://cdn.shopify.com/s/files/1/0037/7690/5283/files/cart_icon_93f3b819-aa16-479e-b6ba-c5007e8520d2.png?v=1623129140">
        </a>
        <div style="margin-left:10px;" id='CartIcon'></div>
        </div>
      
       </div>`
}

export default navbar1;