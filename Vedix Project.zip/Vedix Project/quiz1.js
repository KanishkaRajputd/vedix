function clorChange(){
var p=document.querySelector(".bu1");
p.style.backgroundColor="rgb(226, 130, 95)";


}
function clorChange1(){
    var p=document.querySelector(".bu2");
    p.style.backgroundColor="rgb(226, 130, 95)";
    
    
    }
    function clorChange2(){
        var p=document.querySelector(".bu3");
        p.style.backgroundColor="rgb(226, 130, 95)";
        
        
}
     function clorChange3(){
    var p=document.querySelector(".bu4");
    p.style.backgroundColor="rgb(226, 130, 95)";
            
            
            }
     function clorChange4(){
     var p=document.querySelector(".bu5");
      p.style.backgroundColor="rgb(226, 130, 95)";
                
                
                }
    function clorChange5(){
    var p=document.querySelector(".bu6");
     p.style.backgroundColor="rgb(226, 130, 95)";                
                
        }
 function clorChange6(){
            var p=document.querySelector(".bu7");
             p.style.backgroundColor="rgb(226, 130, 95)";                
                        
                }
function clorChange7(){
                    var p=document.querySelector(".bu8");
                     p.style.backgroundColor="rgb(226, 130, 95)";                
                                
                        }
 function clorChange8(){
                var p=document.querySelector("#bu9");
                p.style.backgroundColor="rgb(226, 130, 95)";  
                var arr=[];
                var s="Acne"   
                arr.push(s);
                localStorage.setItem("s",JSON.stringify(arr))  ;                        
                                        
                                }                                                                
function clorChange9(){
                 var p=document.querySelector("#bu10");
                 p.style.backgroundColor="rgb(226, 130, 95)";  
                 var arr=[];
                 var s="Dark spots"   
                  arr.push(s);
                  localStorage.setItem("s",JSON.stringify(arr))                  
                                                
                  }
 function clorChange10(){
     var p=document.querySelector("#bu11");
      p.style.backgroundColor="rgb(226, 130, 95)";   
      var arr=[] ; 
      var s="Tan"   
     arr.push(s);
     localStorage.setItem("s",JSON.stringify(arr))              
                                                        
     }

    function clorChange11(){
                                                   
        var p=document.querySelector("#bu12");                                        
        p.style.backgroundColor="rgb(226, 130, 95)";     
        var arr=[];
        var s="Aging"  ;
    arr.push(s);
    localStorage.setItem("s",JSON.stringify(arr))  ;           
                                                                
     }
     function clorChange12(){
    var p=document.querySelector("#bu13");
    p.style.backgroundColor="rgb(226, 130, 95)";                
                                                                        
     }
    function clorChange13(){
       var p=document.querySelector("#bu14");
       p.style.backgroundColor="rgb(226, 130, 95)";                
                                                                                
}
function clorChange14(){
      var p=document.querySelector("#bu15");
     p.style.backgroundColor="rgb(226, 130, 95)";                
                                                                                    
    }
       function clorChange15(){
           var p=document.querySelector("#bu16");
         p.style.backgroundColor="rgb(226, 130, 95)";                
                                                                                                
         }               
         function clorChange16(){
         var p=document.querySelector("#bu17");
         p.style.backgroundColor="rgb(226, 130, 95)";                
                                                                                                     
         }
          function clorChange17(){
               var p=document.querySelector("#bu18");
             p.style.backgroundColor="rgb(226, 130, 95)";                
                                                                                                                
     }              
     
     function clorChange18(){
                                                                                                           
        var p=document.querySelector("#bu19");
                                                                                                            
        p.style.backgroundColor="rgb(226, 130, 95)";                
                                                                                                                        
          }
    function clorChange19(){
                                                                                                           
     var p=document.querySelector("#bu20");
                                                                                                                
 p.style.backgroundColor="rgb(226, 130, 95)";                
                                                                                                                            
             }
  function clorChange20(){
                                                                                                           
     var p=document.querySelector("#bu21");
                                                                                                                    
                p.style.backgroundColor="rgb(226, 130, 95)";                
                                                                                                                                
                  }



 function clorChange21(){
                                                                                                           
                   
    var p=document.querySelector("#bu22");
                                                                                                                                   
                               
    p.style.backgroundColor="rgb(226, 130, 95)"; 
    var arr=[];
                 var t="Dry"   
                  arr.push(t);
                  localStorage.setItem("t",JSON.stringify(arr))  
   
                              
                               
         }

 function clorChange22(){
                                                                                                           
         var p=document.querySelector("#bu23");
                                                                                                                                                                                        
         p.style.backgroundColor="rgb(226, 130, 95)"; 
         var arr=[];
                 var t="Oily"   
                  arr.push(t);
                  localStorage.setItem("t",JSON.stringify(arr))  
                
                                                                                                                                                               
}
    function clorChange23(){
                                                                                                           
     var p=document.querySelector("#bu24");                                                                                                               
     p.style.backgroundColor="rgb(226, 130, 95)"; 
     var arr=[];
    var t="Normal"   
    arr.push(t);
    localStorage.setItem("t",JSON.stringify(arr))  
                   
                                                                                                                                                                               
     }
    function clorChange24(){
                                                                                                           
                                                                   
        var p=document.querySelector("#bu25");                                                                       
        p.style.backgroundColor="rgb(226, 130, 95)"; 
        var arr=[];
        var t="Sensitive";   
        arr.push(t);
        localStorage.setItem("t",JSON.stringify(arr))  
                                                                                                                                                                                    
      }
function com(){


        var arr=[];
        var a=document.querySelector("#name").value;
      
        arr.push(a);
        console.log(a);
        localStorage.setItem("a",JSON.stringify(arr));          
        window.location.href="comp.html";


}
